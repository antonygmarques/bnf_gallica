<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-skeleditor?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'skeleditor_description' => 'En espacio privado, no prohibe a redactor los esqueletos de los archivos',
	'skeleditor_slogan' => 'Redactor esquelético'
);
